=====================================

Create : Bartes dwiky (Mr_Xd0wnz)
Team   : C L A Y Hacker Team
contact: clayhackerteam404@gmail.com

=====================================
open to claymore 

$ cd claymore

$ python2 claymore.py




#DILARANG KERAS UNTUK RECODE!!! 